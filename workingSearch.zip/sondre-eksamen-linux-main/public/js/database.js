// Initialize Firebase
var config = {
    apiKey: "AIzaSyB3Wnnl-ENv0dGBLXTARFtpC7TJQk7403M",
    authDomain: "eksamen-linux.firebaseapp.com",
    databaseURL: "https://eksamen-linux.firebaseio.com",
    projectId: "eksamen-linux",
    storageBucket: "eksamen-linux.appspot.com",
    messagingSenderId: "1051366519671"
};
firebase.initializeApp(config);